import 'package:chiffre_conseil_scan/ocr/layout.dart';
import 'package:flutter_test/flutter_test.dart';

// Test minimal (les écrans utilisent des plugins natifs : caméra, OCR).
void main() {
  test('OcrPage vide', () {
    const p = OcrPage(index: 0, paragraphs: [], words: []);
    expect(p.isEmpty, isTrue);
  });
}
