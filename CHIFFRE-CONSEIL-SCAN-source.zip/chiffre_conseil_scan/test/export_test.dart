import 'dart:convert';

import 'package:chiffre_conseil_scan/export/docx_writer.dart';
import 'package:chiffre_conseil_scan/export/xlsx_writer.dart';
import 'package:chiffre_conseil_scan/export/zip_writer.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('crc32 de référence', () {
    expect(crc32(utf8.encode('123456789')), 0xCBF43926);
  });

  test('columnLetter', () {
    expect(columnLetter(0), 'A');
    expect(columnLetter(25), 'Z');
    expect(columnLetter(26), 'AA');
    expect(columnLetter(701), 'ZZ');
    expect(columnLetter(702), 'AAA');
  });

  test('xmlEscape', () {
    expect(xmlEscape('a<b & "c"'), contains('&lt;'));
    expect(xmlEscape('a<b & "c"'), contains('&amp;'));
  });

  test('buildDocx produit une archive Word', () {
    final bytes = buildDocx([
      const DocPage(paragraphs: ['Bonjour', 'Facture n° 12 & co']),
      const DocPage(table: [
        ['A', 'B'],
        ['1', '2'],
      ]),
    ]);
    expect(String.fromCharCodes(bytes.sublist(0, 2)), 'PK');
    final text = latin1.decode(bytes, allowInvalid: true);
    expect(text, contains('word/document.xml'));
    expect(text, contains('[Content_Types].xml'));
  });

  test('buildXlsx produit un classeur avec nombres', () {
    final bytes = buildXlsx([
      const SheetData('Page 1', [
        ['Désignation', 'Montant'],
        ['Paie', '1 250,500'],
      ]),
      const SheetData('Page 1', [
        ['x'],
      ]),
    ]);
    expect(String.fromCharCodes(bytes.sublist(0, 2)), 'PK');
    final text = latin1.decode(bytes, allowInvalid: true);
    expect(text, contains('xl/worksheets/sheet2.xml'));
    expect(text, contains('<v>1250.5</v>'));
  });
}
