import 'package:chiffre_conseil_scan/ocr/layout.dart';
import 'package:flutter_test/flutter_test.dart';

OcrWord w(String t, double x, double y) => OcrWord(t, x, y, x + 10.0 * t.length, y + 20);

void main() {
  test('buildTable reconstitue lignes et colonnes', () {
    final words = [
      w('Désignation', 10, 10), w('Qté', 300, 12), w('Prix', 420, 9),
      w('Conseil', 10, 40), w('fiscal', 90, 41), w('2', 300, 40), w('1', 420, 42), w('250,500', 435, 42),
      w('Paie', 10, 70), w('10', 300, 71), w('400,000', 420, 69),
    ];
    expect(buildTable(words), [
      ['Désignation', 'Qté', 'Prix'],
      ['Conseil fiscal', '2', '1 250,500'],
      ['Paie', '10', '400,000'],
    ]);
  });

  test('buildTable sur une page vide', () {
    expect(buildTable(const []), isEmpty);
  });

  test('parseNumber : formats français et anglais', () {
    expect(parseNumber('1 250,500'), 1250.5);
    expect(parseNumber('12,5'), 12.5);
    expect(parseNumber('1.234,56'), 1234.56);
    expect(parseNumber('1,234.56'), 1234.56);
    expect(parseNumber('1,234,567'), 1234567);
    expect(parseNumber('-42'), -42);
    expect(parseNumber('(12,5)'), -12.5);
    expect(parseNumber('0,75'), 0.75);
  });

  test('parseNumber : texte et codes restent du texte', () {
    expect(parseNumber('Conseil'), isNull);
    expect(parseNumber('007'), isNull);
    expect(parseNumber('1952422XAM000'), isNull);
    expect(parseNumber(''), isNull);
  });
}
