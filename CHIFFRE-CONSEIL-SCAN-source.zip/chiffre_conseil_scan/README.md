# Chiffre Conseil Scan — application Android

Convertit des **photos** et des **PDF** en fichiers **Word (.docx)** et **Excel (.xlsx)**.
Sans compte, sans inscription, sans Internet : la reconnaissance de texte (OCR) se fait sur le téléphone.

## Fonctions
- Scanner un document avec l'appareil photo (plusieurs pages possibles)
- Importer une ou plusieurs images depuis la galerie
- Importer un PDF (jusqu'à 40 pages)
- Texte modifiable avant export, aperçu du tableau détecté
- Word : texte en paragraphes ou mise en page en tableau
- Excel : une feuille par page ou une seule feuille ; les montants (« 1 250,500 ») deviennent des nombres
- Ouvrir dans Word / Excel / WPS / Google Docs-Sheets, ou « Enregistrer sous » (Téléchargements, Drive)
- Historique des fichiers créés, thème clair / sombre automatique

## Compiler l'APK avec GitHub (depuis le téléphone)
1. Créez un dépôt (privé possible) sur github.com, par exemple `chiffre-conseil-scan`.
2. **Add file → Upload files** : envoyez `CHIFFRE-CONSEIL-SCAN-source.zip` → **Commit changes**.
3. **Add file → Create new file** : nommez-le exactement `.github/workflows/build.yml`,
   collez le contenu de `build.yml.txt` → **Commit changes**.
4. Onglet **Actions** : la compilation démarre (≈ 10 à 15 min).
5. Quand le rond est vert, ouvrez l'exécution → **Artifacts** → `Chiffre-Conseil-Scan-android` (fichier zip) :
   - `Chiffre-Conseil-Scan-arm64-leger.apk` : le plus léger, pour la plupart des téléphones récents
   - `Chiffre-Conseil-Scan.apk` : version universelle
   - `Chiffre-Conseil-Scan-debug.apk` : version de test

Pour publier une mise à jour : remplacez le zip dans le dépôt, la compilation repart seule.

## Limites connues
- OCR : alphabet latin (français, anglais…). L'arabe n'est pas pris en charge par ce moteur.
- Les colonnes du tableau sont reconstituées à partir de la position des mots : vérifiez le résultat,
  surtout pour les tableaux sans bordures ou les cellules sur plusieurs lignes.
- Une photo nette, bien éclairée et à plat donne de bien meilleurs résultats.
- Les PDF protégés par mot de passe ne peuvent pas être ouverts.
- Signature : sans clé de publication, GitHub signe avec une clé de test qui change à chaque compilation
  (il faut alors désinstaller avant d'installer une nouvelle version).

## Technique
Flutter · google_mlkit_text_recognition (modèle latin intégré) · printing (PDF → images) ·
générateurs DOCX/XLSX écrits en Dart, sans dépendance (dossier `lib/export/`) · tests dans `test/`.
Identifiant : `net.chiffreconseil.scan`. Aucune permission Internet.
