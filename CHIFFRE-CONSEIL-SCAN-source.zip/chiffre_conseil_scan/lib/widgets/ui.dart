import 'package:flutter/material.dart';

import '../core/theme.dart';

AppBar ccBar(BuildContext context, String title, {List<Widget>? actions}) => AppBar(
      title: Text(title, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: context.strong)),
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      foregroundColor: context.strong,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      actions: actions,
    );

class CardBox extends StatelessWidget {
  const CardBox({super.key, required this.child, this.onTap, this.onLongPress, this.padding = const EdgeInsets.all(16), this.color});
  final Widget child;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final EdgeInsets padding;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final r = BorderRadius.circular(18);
    return Material(
      color: color ?? context.card,
      borderRadius: r,
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        onLongPress: onLongPress,
        child: Container(
          padding: padding,
          decoration: BoxDecoration(borderRadius: r, border: Border.all(color: context.lineC)),
          child: child,
        ),
      ),
    );
  }
}

class IconTile extends StatelessWidget {
  const IconTile(this.icon, {super.key, this.color = CC.navy, this.size = 48});
  final IconData icon;
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(color: color.withValues(alpha: context.isDark ? 0.25 : 0.1), borderRadius: BorderRadius.circular(size * 0.3)),
        child: Icon(icon, color: context.isDark && color == CC.navy ? CC.orangeLight : color, size: size * 0.52),
      );
}

class BigButton extends StatelessWidget {
  const BigButton(this.label, {super.key, required this.onPressed, this.icon, this.color = CC.orange});
  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final Color color;

  @override
  Widget build(BuildContext context) => SizedBox(
        width: double.infinity,
        child: FilledButton(
          onPressed: onPressed,
          style: FilledButton.styleFrom(
            backgroundColor: color,
            foregroundColor: Colors.white,
            minimumSize: const Size(0, 54),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            textStyle: const TextStyle(fontFamily: 'Montserrat', fontWeight: FontWeight.w800, fontSize: 14.5, letterSpacing: 0.5),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            if (icon != null) ...[Icon(icon, size: 20), const SizedBox(width: 10)],
            Flexible(child: Text(label, textAlign: TextAlign.center)),
          ]),
        ),
      );
}

void snack(BuildContext context, String msg, {bool error = false}) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating, backgroundColor: error ? CC.danger : CC.navy));
}
