// Reconstruction de la mise en page à partir des mots détectés par l'OCR :
// paragraphes (Word) et tableau lignes × colonnes (Excel). Code Dart pur, testé.

class OcrWord {
  final String text;
  final double left, top, right, bottom;
  const OcrWord(this.text, this.left, this.top, this.right, this.bottom);
  double get height => bottom - top;
  double get cy => (top + bottom) / 2;
}

/// Résultat OCR d'une page.
class OcrPage {
  final int index;
  final List<String> paragraphs; // un paragraphe par bloc de texte détecté
  final List<OcrWord> words;
  const OcrPage({required this.index, required this.paragraphs, required this.words});

  String get text => paragraphs.join('\n\n');
  bool get isEmpty => words.isEmpty && paragraphs.every((p) => p.trim().isEmpty);
}

double _median(List<double> v) {
  if (v.isEmpty) return 0;
  final s = [...v]..sort();
  final m = s.length ~/ 2;
  return s.length.isOdd ? s[m] : (s[m - 1] + s[m]) / 2;
}

class _Cell {
  final double left, right;
  final String text;
  const _Cell(this.left, this.right, this.text);
}

/// Regroupe les mots en lignes (même hauteur) puis en cellules (écarts horizontaux),
/// et aligne les cellules sur des colonnes communes.
List<List<String>> buildTable(List<OcrWord> words) {
  final ws = words.where((w) => w.text.trim().isNotEmpty && w.height > 0).toList();
  if (ws.isEmpty) return [];
  final h = _median(ws.map((w) => w.height).toList());
  final tolY = h * 0.6;
  final gapX = h * 1.1;

  // 1. lignes
  ws.sort((a, b) => a.cy.compareTo(b.cy));
  final rows = <List<OcrWord>>[];
  final rowCy = <double>[];
  for (final w in ws) {
    if (rows.isNotEmpty && (w.cy - rowCy.last).abs() <= tolY) {
      rows.last.add(w);
      final n = rows.last.length;
      rowCy[rowCy.length - 1] = rowCy.last + (w.cy - rowCy.last) / n;
    } else {
      rows.add([w]);
      rowCy.add(w.cy);
    }
  }

  // 2. cellules par ligne
  final cellRows = <List<_Cell>>[];
  for (final r in rows) {
    r.sort((a, b) => a.left.compareTo(b.left));
    final cells = <_Cell>[];
    var buf = StringBuffer(r.first.text);
    var l = r.first.left, rr = r.first.right;
    for (var i = 1; i < r.length; i++) {
      final w = r[i];
      if (w.left - rr > gapX) {
        cells.add(_Cell(l, rr, buf.toString()));
        buf = StringBuffer(w.text);
        l = w.left;
      } else {
        buf.write(' ');
        buf.write(w.text);
      }
      if (w.right > rr) rr = w.right;
    }
    cells.add(_Cell(l, rr, buf.toString()));
    cellRows.add(cells);
  }

  // 3. colonnes : regroupement des abscisses de début de cellule
  final lefts = <double>[for (final r in cellRows) for (final c in r) c.left]..sort();
  final clusters = <List<double>>[];
  for (final x in lefts) {
    if (clusters.isNotEmpty && x - clusters.last.last <= h * 1.5) {
      clusters.last.add(x);
    } else {
      clusters.add([x]);
    }
  }
  final colX = clusters.map((c) => c.reduce((a, b) => a + b) / c.length).toList();
  int colOf(double x) {
    var best = 0;
    var bestD = double.infinity;
    for (var i = 0; i < colX.length; i++) {
      final d = (x - colX[i]).abs();
      if (d < bestD) {
        bestD = d;
        best = i;
      }
    }
    return best;
  }

  final grid = <List<String>>[];
  for (final r in cellRows) {
    final line = List<String>.filled(colX.length, '');
    for (final c in r) {
      final k = colOf(c.left);
      line[k] = line[k].isEmpty ? c.text : '${line[k]} ${c.text}';
    }
    grid.add(line);
  }
  // supprime les colonnes entièrement vides
  final keep = <int>[
    for (var i = 0; i < colX.length; i++)
      if (grid.any((r) => r[i].trim().isNotEmpty)) i,
  ];
  return [for (final r in grid) [for (final i in keep) r[i]]];
}

/// Lignes de texte simples (une ligne visuelle = une ligne), utiles pour Word.
List<String> buildLines(List<OcrWord> words) =>
    buildTable(words).map((r) => r.where((c) => c.isNotEmpty).join('    ')).toList();

/// Valeur numérique d'une cellule (« 1 234,50 », « -12.5 », « 1,234,567 »), sinon null.
double? parseNumber(String raw) {
  var s = raw.trim().replaceAll(RegExp(r'[\s  ]'), '');
  if (s.isEmpty || s.length > 18) return null;
  var neg = false;
  if (s.startsWith('(') && s.endsWith(')')) {
    neg = true;
    s = s.substring(1, s.length - 1);
  }
  if (s.startsWith('-')) {
    neg = !neg;
    s = s.substring(1);
  } else if (s.startsWith('+')) {
    s = s.substring(1);
  }
  if (!RegExp(r'^\d[\d.,]*$').hasMatch(s)) return null;
  // zéros de tête (codes, matricules) : rester en texte
  if (s.length > 1 && s.startsWith('0') && !s.startsWith('0,') && !s.startsWith('0.')) return null;
  final lastComma = s.lastIndexOf(',');
  final lastDot = s.lastIndexOf('.');
  String norm;
  if (lastComma >= 0 && lastDot >= 0) {
    norm = lastComma > lastDot ? s.replaceAll('.', '').replaceAll(',', '.') : s.replaceAll(',', '');
  } else if (lastComma >= 0) {
    final parts = s.split(',');
    if (parts.length > 2) {
      if (!parts.skip(1).every((p) => p.length == 3)) return null;
      norm = s.replaceAll(',', '');
    } else {
      norm = s.replaceAll(',', '.');
    }
  } else if (lastDot >= 0) {
    final parts = s.split('.');
    if (parts.length > 2) {
      if (!parts.skip(1).every((p) => p.length == 3)) return null;
      norm = s.replaceAll('.', '');
    } else {
      norm = s;
    }
  } else {
    norm = s;
  }
  final v = double.tryParse(norm);
  if (v == null) return null;
  return neg ? -v : v;
}
