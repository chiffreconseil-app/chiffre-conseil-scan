import 'dart:io';
import 'dart:typed_data';

import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:path_provider/path_provider.dart';
import 'package:printing/printing.dart';

import 'layout.dart';

/// Reconnaissance de texte 100 % sur l'appareil (Google ML Kit, modèle embarqué).
class OcrService {
  OcrService._();
  static final instance = OcrService._();

  static const maxPdfPages = 40;

  Future<OcrPage> recognizeFile(String path, int index) async {
    final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
    try {
      final result = await recognizer.processImage(InputImage.fromFilePath(path));
      final paragraphs = <String>[];
      final words = <OcrWord>[];
      for (final block in result.blocks) {
        final lines = block.lines.map((l) => l.text.trim()).where((t) => t.isNotEmpty).toList();
        if (lines.isNotEmpty) paragraphs.add(lines.join('\n'));
        for (final line in block.lines) {
          for (final e in line.elements) {
            final r = e.boundingBox;
            words.add(OcrWord(e.text, r.left, r.top, r.right, r.bottom));
          }
        }
      }
      return OcrPage(index: index, paragraphs: paragraphs, words: words);
    } finally {
      await recognizer.close();
    }
  }

  /// Convertit chaque page d'un PDF en image PNG (220 dpi) dans le dossier temporaire.
  /// [onPage] est appelé après chaque page rendue (numéro, total inconnu = -1).
  Future<List<String>> pdfToImages(String pdfPath, {void Function(int done)? onPage}) async {
    final bytes = await File(pdfPath).readAsBytes();
    final tmp = await getTemporaryDirectory();
    final stamp = DateTime.now().millisecondsSinceEpoch;
    final out = <String>[];
    var i = 0;
    await for (final page in Printing.raster(Uint8List.fromList(bytes), dpi: 220)) {
      final png = await page.toPng();
      final f = File('${tmp.path}/ccscan_${stamp}_${i + 1}.png');
      await f.writeAsBytes(png, flush: true);
      out.add(f.path);
      i++;
      onPage?.call(i);
      if (i >= maxPdfPages) break;
    }
    return out;
  }
}
