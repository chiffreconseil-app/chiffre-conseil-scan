import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../services/export_store.dart';
import '../widgets/ui.dart';

class FilesScreen extends StatefulWidget {
  const FilesScreen({super.key});

  @override
  State<FilesScreen> createState() => _FilesScreenState();
}

class _FilesScreenState extends State<FilesScreen> {
  List<ExportItem> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final h = await ExportStore.instance.history();
    if (mounted) {
      setState(() {
        _items = h;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: ccBar(context, 'Mes fichiers'),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? Center(child: Text('Aucun fichier pour le moment.', style: TextStyle(color: context.muted)))
              : ListView(
                  padding: const EdgeInsets.only(top: 4, bottom: 40),
                  children: [for (final it in _items) FileTile(item: it, onChanged: _load)],
                ),
    );
  }
}

String _date(DateTime d) =>
    '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year} ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

class FileTile extends StatelessWidget {
  const FileTile({super.key, required this.item, required this.onChanged});
  final ExportItem item;
  final VoidCallback onChanged;

  Future<void> _open(BuildContext context) async {
    final err = await ExportStore.instance.open(item);
    if (err != null && context.mounted) snack(context, err, error: true);
  }

  Future<void> _menu(BuildContext context) async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      backgroundColor: context.card,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.open_in_new), title: const Text('Ouvrir'), onTap: () => Navigator.pop(ctx, 'open')),
          ListTile(leading: const Icon(Icons.save_alt), title: const Text('Enregistrer sous… (Téléchargements, Drive)'), onTap: () => Navigator.pop(ctx, 'save')),
          ListTile(leading: const Icon(Icons.delete_outline, color: CC.danger), title: const Text('Supprimer'), onTap: () => Navigator.pop(ctx, 'delete')),
        ]),
      ),
    );
    if (!context.mounted || choice == null) return;
    if (choice == 'open') {
      await _open(context);
    } else if (choice == 'save') {
      final ok = await ExportStore.instance.saveAs(item);
      if (context.mounted && ok) snack(context, 'Fichier enregistré.');
    } else if (choice == 'delete') {
      await ExportStore.instance.delete(item);
      onChanged();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isWord = item.kind == 'docx';
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 6),
      child: CardBox(
        padding: const EdgeInsets.fromLTRB(12, 12, 4, 12),
        onTap: () => _open(context),
        onLongPress: () => _menu(context),
        child: Row(children: [
          IconTile(isWord ? Icons.description : Icons.grid_on, color: isWord ? CC.word : CC.excel, size: 44),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w700, color: context.strong)),
              const SizedBox(height: 2),
              Text('${isWord ? 'Word' : 'Excel'} · ${item.pages} page(s) · ${_date(item.date)}',
                  style: TextStyle(fontSize: 12, color: context.muted)),
            ]),
          ),
          IconButton(onPressed: () => _menu(context), icon: Icon(Icons.more_vert, color: context.muted)),
        ]),
      ),
    );
  }
}
