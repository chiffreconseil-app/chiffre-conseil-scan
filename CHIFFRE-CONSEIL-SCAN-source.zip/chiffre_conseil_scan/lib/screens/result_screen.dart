import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/theme.dart';
import '../export/docx_writer.dart';
import '../export/xlsx_writer.dart';
import '../ocr/layout.dart';
import '../services/export_store.dart';
import '../widgets/ui.dart';

class ResultScreen extends StatefulWidget {
  const ResultScreen({super.key, required this.pages, required this.title});
  final List<OcrPage> pages;
  final String title;

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  late final List<TextEditingController> _text = [for (final p in widget.pages) TextEditingController(text: p.text)];
  late final List<List<List<String>>> _tables = [for (final p in widget.pages) buildTable(p.words)];
  bool _exporting = false;

  @override
  void dispose() {
    for (final c in _text) {
      c.dispose();
    }
    super.dispose();
  }

  bool get _empty => widget.pages.every((p) => p.isEmpty);

  String get _baseName {
    final d = DateTime.now();
    String two(int v) => v.toString().padLeft(2, '0');
    return '${widget.title}_${d.year}${two(d.month)}${two(d.day)}_${two(d.hour)}${two(d.minute)}';
  }

  Future<String?> _choose(String title, List<(String, String, IconData)> options) => showModalBottomSheet<String>(
        context: context,
        showDragHandle: true,
        backgroundColor: context.card,
        builder: (ctx) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 0, 8, 12),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                child: Text(title, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: ctx.strong)),
              ),
              for (final o in options)
                ListTile(
                  leading: Icon(o.$3),
                  title: Text(o.$2, style: const TextStyle(fontWeight: FontWeight.w600)),
                  onTap: () => Navigator.pop(ctx, o.$1),
                ),
            ]),
          ),
        ),
      );

  Future<void> _exportWord() async {
    final mode = await _choose('Créer un fichier Word', [
      ('text', 'Texte (paragraphes, avec vos corrections)', Icons.notes),
      ('table', 'Mise en page en tableau (colonnes détectées)', Icons.table_chart_outlined),
    ]);
    if (mode == null) return;
    final pages = <DocPage>[
      for (var i = 0; i < widget.pages.length; i++)
        mode == 'table'
            ? DocPage(table: _tables[i])
            : DocPage(paragraphs: _text[i].text.split(RegExp(r'\n\s*\n')).map((p) => p.trim()).where((p) => p.isNotEmpty).toList()),
    ];
    await _finish(buildDocx(pages), 'docx');
  }

  Future<void> _exportExcel() async {
    final mode = await _choose('Créer un fichier Excel', [
      ('sheets', 'Une feuille par page', Icons.layers_outlined),
      ('single', 'Toutes les pages dans une seule feuille', Icons.view_agenda_outlined),
    ]);
    if (mode == null) return;
    final List<SheetData> sheets;
    if (mode == 'single') {
      final rows = <List<String>>[];
      for (var i = 0; i < _tables.length; i++) {
        if (i > 0) rows.add(<String>[]);
        rows.addAll(_tables[i]);
      }
      sheets = [SheetData('Scan', rows)];
    } else {
      sheets = [for (var i = 0; i < _tables.length; i++) SheetData('Page ${i + 1}', _tables[i])];
    }
    await _finish(buildXlsx(sheets), 'xlsx');
  }

  Future<void> _finish(Uint8List bytes, String ext) async {
    setState(() => _exporting = true);
    try {
      final item = await ExportStore.instance.save(bytes, baseName: _baseName, ext: ext, pages: widget.pages.length);
      if (!mounted) return;
      setState(() => _exporting = false);
      await _done(item);
    } catch (e) {
      if (mounted) {
        setState(() => _exporting = false);
        snack(context, 'Création du fichier impossible : $e', error: true);
      }
    }
  }

  Future<void> _done(ExportItem item) async {
    final isWord = item.kind == 'docx';
    final action = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        icon: Icon(Icons.check_circle, color: isWord ? CC.word : CC.excel, size: 48),
        title: Text(isWord ? 'Fichier Word créé' : 'Fichier Excel créé'),
        content: Text(item.name, textAlign: TextAlign.center),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, 'save'), child: const Text('Enregistrer sous…')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: isWord ? CC.word : CC.excel),
            onPressed: () => Navigator.pop(ctx, 'open'),
            child: const Text('Ouvrir'),
          ),
        ],
      ),
    );
    if (!mounted || action == null) return;
    if (action == 'open') {
      final err = await ExportStore.instance.open(item);
      if (err != null && mounted) snack(context, err, error: true);
    } else {
      final ok = await ExportStore.instance.saveAs(item);
      if (ok && mounted) snack(context, 'Fichier enregistré.');
    }
  }

  void _copy() {
    final all = [for (var i = 0; i < _text.length; i++) _text[i].text].join('\n\n');
    Clipboard.setData(ClipboardData(text: all));
    snack(context, 'Texte copié.');
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Résultat', style: TextStyle(fontWeight: FontWeight.w800, color: context.strong)),
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          foregroundColor: context.strong,
          surfaceTintColor: Colors.transparent,
          actions: [IconButton(onPressed: _empty ? null : _copy, icon: const Icon(Icons.copy_all_outlined), tooltip: 'Copier le texte')],
          bottom: TabBar(
            labelColor: context.accent,
            indicatorColor: CC.orange,
            unselectedLabelColor: context.muted,
            labelStyle: const TextStyle(fontFamily: 'Montserrat', fontWeight: FontWeight.w800),
            tabs: const [Tab(text: 'Texte', icon: Icon(Icons.notes)), Tab(text: 'Tableau', icon: Icon(Icons.table_chart_outlined))],
          ),
        ),
        body: _empty
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(30),
                  child: Text(
                    'Aucun texte détecté. Reprenez la photo avec plus de lumière, bien à plat, sans flou.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: context.muted, height: 1.5),
                  ),
                ),
              )
            : TabBarView(children: [_textTab(), _tableTab()]),
        bottomNavigationBar: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: _exporting
                ? const SizedBox(height: 54, child: Center(child: CircularProgressIndicator()))
                : Row(children: [
                    Expanded(child: BigButton('WORD', icon: Icons.description, color: CC.word, onPressed: _empty ? null : _exportWord)),
                    const SizedBox(width: 12),
                    Expanded(child: BigButton('EXCEL', icon: Icons.grid_on, color: CC.excel, onPressed: _empty ? null : _exportExcel)),
                  ]),
          ),
        ),
      ),
    );
  }

  Widget _textTab() => ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        itemCount: _text.length,
        itemBuilder: (context, i) => Padding(
          padding: const EdgeInsets.only(bottom: 14),
          child: CardBox(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 6),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('PAGE ${i + 1} — modifiable', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.2, color: context.accent)),
              TextField(
                controller: _text[i],
                maxLines: null,
                minLines: 4,
                style: TextStyle(fontSize: 14.5, height: 1.45, color: context.strong),
                decoration: const InputDecoration(border: InputBorder.none, hintText: 'Aucun texte sur cette page'),
              ),
            ]),
          ),
        ),
      );

  Widget _tableTab() => ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        itemCount: _tables.length,
        itemBuilder: (context, i) {
          final t = _tables[i];
          final cols = t.fold<int>(0, (m, r) => r.length > m ? r.length : m);
          return Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: CardBox(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('PAGE ${i + 1} — ${t.length} ligne(s) × $cols colonne(s)',
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.2, color: context.accent)),
                const SizedBox(height: 8),
                if (t.isEmpty || cols == 0)
                  Text('Aucune donnée détectée.', style: TextStyle(color: context.muted))
                else
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Table(
                      defaultColumnWidth: const IntrinsicColumnWidth(),
                      border: TableBorder.all(color: context.lineC),
                      children: [
                        for (var r = 0; r < t.length; r++)
                          TableRow(
                            decoration: BoxDecoration(color: r == 0 ? CC.navy.withValues(alpha: 0.08) : null),
                            children: [
                              for (var c = 0; c < cols; c++)
                                Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                                  child: ConstrainedBox(
                                    constraints: const BoxConstraints(maxWidth: 220),
                                    child: Text(c < t[r].length ? t[r][c] : '',
                                        style: TextStyle(fontSize: 12.5, fontWeight: r == 0 ? FontWeight.w700 : FontWeight.w400, color: context.strong)),
                                  ),
                                ),
                            ],
                          ),
                      ],
                    ),
                  ),
                const SizedBox(height: 6),
                Text('Les colonnes sont reconstituées automatiquement : vérifiez le résultat dans Excel.',
                    style: TextStyle(fontSize: 11.5, color: context.muted)),
              ]),
            ),
          );
        },
      );
}
