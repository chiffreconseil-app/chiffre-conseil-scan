import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../core/theme.dart';
import '../ocr/layout.dart';
import '../ocr/ocr_service.dart';
import '../widgets/ui.dart';
import 'result_screen.dart';

/// Vérification des pages avant conversion : ajout, suppression.
class PagesScreen extends StatefulWidget {
  const PagesScreen({super.key, required this.initialPaths, required this.title});
  final List<String> initialPaths;
  final String title;

  @override
  State<PagesScreen> createState() => _PagesScreenState();
}

class _PagesScreenState extends State<PagesScreen> {
  late final List<String> _paths = [...widget.initialPaths];
  final _picker = ImagePicker();

  Future<void> _add(ImageSource src) async {
    try {
      if (src == ImageSource.camera) {
        final x = await _picker.pickImage(source: ImageSource.camera, imageQuality: 92, maxWidth: 3000, maxHeight: 3000);
        if (x != null) setState(() => _paths.add(x.path));
      } else {
        final xs = await _picker.pickMultiImage(imageQuality: 92, maxWidth: 3000, maxHeight: 3000);
        if (xs.isNotEmpty) setState(() => _paths.addAll(xs.map((e) => e.path)));
      }
    } catch (e) {
      if (mounted) snack(context, 'Ajout impossible : $e', error: true);
    }
  }

  void _addMenu() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      backgroundColor: context.card,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.photo_camera_outlined),
            title: const Text('Photographier une page'),
            onTap: () {
              Navigator.pop(ctx);
              _add(ImageSource.camera);
            },
          ),
          ListTile(
            leading: const Icon(Icons.photo_library_outlined),
            title: const Text('Ajouter depuis la galerie'),
            onTap: () {
              Navigator.pop(ctx);
              _add(ImageSource.gallery);
            },
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cols = MediaQuery.sizeOf(context).width > 600 ? 4 : 2;
    return Scaffold(
      appBar: ccBar(context, '${_paths.length} page(s)', actions: [
        IconButton(onPressed: _addMenu, icon: const Icon(Icons.add_a_photo_outlined), tooltip: 'Ajouter une page'),
      ]),
      body: _paths.isEmpty
          ? Center(child: Text('Aucune page. Ajoutez une photo.', style: TextStyle(color: context.muted)))
          : GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: cols, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 0.72),
              itemCount: _paths.length,
              itemBuilder: (context, i) => Stack(children: [
                Positioned.fill(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: Container(
                      color: context.card,
                      child: Image.file(File(_paths[i]), fit: BoxFit.cover, cacheWidth: 600,
                          errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.broken_image_outlined))),
                    ),
                  ),
                ),
                Positioned(
                  left: 8,
                  top: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                    decoration: BoxDecoration(color: CC.navy.withValues(alpha: 0.85), borderRadius: BorderRadius.circular(20)),
                    child: Text('${i + 1}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                  ),
                ),
                Positioned(
                  right: 4,
                  top: 4,
                  child: IconButton.filled(
                    style: IconButton.styleFrom(backgroundColor: Colors.black.withValues(alpha: 0.55)),
                    onPressed: () => setState(() => _paths.removeAt(i)),
                    icon: const Icon(Icons.close, size: 18, color: Colors.white),
                    tooltip: 'Retirer',
                  ),
                ),
              ]),
            ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: BigButton(
            _paths.isEmpty ? 'AJOUTER UNE PAGE' : 'CONVERTIR ${_paths.length} PAGE(S)',
            icon: _paths.isEmpty ? Icons.add : Icons.auto_awesome,
            onPressed: _paths.isEmpty
                ? _addMenu
                : () => Navigator.of(context).pushReplacement(MaterialPageRoute<void>(
                      builder: (_) => ProcessingScreen(paths: List<String>.of(_paths), title: widget.title),
                    )),
          ),
        ),
      ),
    );
  }
}

/// Reconnaissance page par page avec progression.
class ProcessingScreen extends StatefulWidget {
  const ProcessingScreen({super.key, required this.paths, required this.title});
  final List<String> paths;
  final String title;

  @override
  State<ProcessingScreen> createState() => _ProcessingScreenState();
}

class _ProcessingScreenState extends State<ProcessingScreen> {
  int _done = 0;
  String? _error;

  @override
  void initState() {
    super.initState();
    _run();
  }

  Future<void> _run() async {
    final results = <OcrPage>[];
    try {
      for (var i = 0; i < widget.paths.length; i++) {
        results.add(await OcrService.instance.recognizeFile(widget.paths[i], i));
        if (!mounted) return;
        setState(() => _done = i + 1);
      }
    } catch (e) {
      if (mounted) setState(() => _error = 'La reconnaissance a échoué : $e');
      return;
    }
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute<void>(builder: (_) => ResultScreen(pages: results, title: widget.title)));
  }

  @override
  Widget build(BuildContext context) {
    final n = widget.paths.length;
    return Scaffold(
      appBar: ccBar(context, 'Conversion'),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: _error != null
              ? Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.error_outline, size: 56, color: CC.danger),
                  const SizedBox(height: 16),
                  Text(_error!, textAlign: TextAlign.center, style: TextStyle(color: context.strong)),
                  const SizedBox(height: 20),
                  BigButton('RETOUR', onPressed: () => Navigator.of(context).pop(), color: CC.navy),
                ])
              : Column(mainAxisSize: MainAxisSize.min, children: [
                  SizedBox(
                    width: 120,
                    height: 120,
                    child: CircularProgressIndicator(value: n == 0 ? null : _done / n, strokeWidth: 9, color: CC.orange,
                        backgroundColor: context.lineC),
                  ),
                  const SizedBox(height: 26),
                  Text('Lecture du texte…', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 20, color: context.strong)),
                  const SizedBox(height: 8),
                  Text('Page ${_done < n ? _done + 1 : n} sur $n — traitement sur votre téléphone',
                      textAlign: TextAlign.center, style: TextStyle(color: context.muted)),
                ]),
        ),
      ),
    );
  }
}
