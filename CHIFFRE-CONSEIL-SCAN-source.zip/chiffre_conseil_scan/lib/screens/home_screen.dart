import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../core/theme.dart';
import '../ocr/ocr_service.dart';
import '../services/export_store.dart';
import '../widgets/ui.dart';
import 'files_screen.dart';
import 'pages_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _picker = ImagePicker();
  List<ExportItem> _recent = [];
  bool _busy = false;
  String _busyText = '';

  @override
  void initState() {
    super.initState();
    _loadRecent();
    ExportStore.instance.changes.addListener(_loadRecent);
  }

  @override
  void dispose() {
    ExportStore.instance.changes.removeListener(_loadRecent);
    super.dispose();
  }

  Future<void> _loadRecent() async {
    final h = await ExportStore.instance.history();
    if (mounted) setState(() => _recent = h);
  }

  Future<void> _openPages(List<String> paths, String title) async {
    if (paths.isEmpty) return;
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => PagesScreen(initialPaths: paths, title: title)));
    _loadRecent();
  }

  Future<void> _camera() async {
    try {
      final x = await _picker.pickImage(source: ImageSource.camera, imageQuality: 92, maxWidth: 3000, maxHeight: 3000);
      if (x != null) await _openPages([x.path], 'Scan');
    } catch (e) {
      if (mounted) snack(context, 'Appareil photo indisponible : $e', error: true);
    }
  }

  Future<void> _gallery() async {
    try {
      final xs = await _picker.pickMultiImage(imageQuality: 92, maxWidth: 3000, maxHeight: 3000);
      if (xs.isNotEmpty) await _openPages(xs.map((x) => x.path).toList(), 'Images');
    } catch (e) {
      if (mounted) snack(context, 'Import impossible : $e', error: true);
    }
  }

  Future<void> _pdf() async {
    try {
      final res = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: const ['pdf']);
      final path = res?.files.single.path;
      if (path == null) return;
      final name = res!.files.single.name.replaceAll(RegExp(r'\.pdf$', caseSensitive: false), '');
      setState(() {
        _busy = true;
        _busyText = 'Préparation des pages du PDF…';
      });
      final images = await OcrService.instance.pdfToImages(path, onPage: (n) {
        if (mounted) setState(() => _busyText = 'Préparation des pages du PDF… ($n)');
      });
      if (!mounted) return;
      setState(() => _busy = false);
      if (images.isEmpty) {
        snack(context, 'Ce PDF ne contient aucune page lisible.', error: true);
        return;
      }
      if (images.length >= OcrService.maxPdfPages) {
        snack(context, 'Seules les ${OcrService.maxPdfPages} premières pages sont traitées.');
      }
      await _openPages(images, name);
    } catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        snack(context, 'PDF illisible ou protégé par mot de passe.', error: true);
      }
    }
  }

  void _about() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      backgroundColor: context.card,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 0, 22, 24),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Image.asset(ctx.isDark ? 'assets/brand/logo_inverse.png' : 'assets/brand/logo_color.png', height: 30),
            const SizedBox(height: 16),
            Text('Chiffre Conseil Scan — version 1.0.0', style: TextStyle(fontWeight: FontWeight.w800, color: ctx.strong)),
            const SizedBox(height: 10),
            Text(
              '• Sans compte, sans inscription.\n'
              '• La reconnaissance de texte (OCR) se fait sur votre téléphone : vos documents ne sont envoyés à aucun serveur.\n'
              '• Langues reconnues : alphabet latin (français, anglais…). L’arabe n’est pas encore pris en charge.\n'
              '• Les fichiers créés restent dans l’application tant que vous ne les enregistrez pas ailleurs.\n'
              '• Vérifiez toujours le résultat : l’OCR peut faire des erreurs, surtout sur les photos floues ou les tableaux complexes.',
              style: TextStyle(height: 1.55, color: ctx.muted),
            ),
            const SizedBox(height: 14),
            Text('CHIFFRE CONSEIL · chiffreconseil.net · +216 99 753 706', style: TextStyle(fontSize: 12, color: ctx.muted)),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(children: [
        RefreshIndicator(
          onRefresh: _loadRecent,
          child: ListView(padding: EdgeInsets.zero, children: [
            _hero(context),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
              child: Column(children: [
                _ActionCard(
                  icon: Icons.document_scanner_outlined,
                  color: CC.orange,
                  title: 'Scanner un document',
                  subtitle: 'Photographiez une facture, un relevé, un tableau…',
                  onTap: _busy ? null : _camera,
                ),
                const SizedBox(height: 12),
                _ActionCard(
                  icon: Icons.photo_library_outlined,
                  color: CC.blue,
                  title: 'Importer des images',
                  subtitle: 'Une ou plusieurs photos depuis la galerie',
                  onTap: _busy ? null : _gallery,
                ),
                const SizedBox(height: 12),
                _ActionCard(
                  icon: Icons.picture_as_pdf_outlined,
                  color: CC.danger,
                  title: 'Importer un PDF',
                  subtitle: 'PDF numérique ou scanné, jusqu’à ${OcrService.maxPdfPages} pages',
                  onTap: _busy ? null : _pdf,
                ),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 26, 8, 6),
              child: Row(children: [
                Expanded(child: Text('Fichiers récents', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: context.strong))),
                if (_recent.isNotEmpty)
                  TextButton(
                    onPressed: () async {
                      await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const FilesScreen()));
                      _loadRecent();
                    },
                    child: Text('Tout voir', style: TextStyle(color: context.accent, fontWeight: FontWeight.w700)),
                  ),
              ]),
            ),
            if (_recent.isEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 0),
                child: Text('Vos fichiers Word et Excel apparaîtront ici.', style: TextStyle(color: context.muted)),
              )
            else
              for (final it in _recent.take(5)) FileTile(item: it, onChanged: _loadRecent),
            const SizedBox(height: 40),
          ]),
        ),
        if (_busy)
          Positioned.fill(
            child: Container(
              color: Colors.black.withValues(alpha: 0.45),
              alignment: Alignment.center,
              child: CardBox(
                padding: const EdgeInsets.all(22),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  const SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 3)),
                  const SizedBox(width: 16),
                  Text(_busyText, style: TextStyle(fontWeight: FontWeight.w700, color: context.strong)),
                ]),
              ),
            ),
          ),
      ]),
    );
  }

  Widget _hero(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(colors: [CC.navySoft, CC.navy, CC.navyDeep], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
      ),
      child: Stack(children: [
        Positioned(
          right: -60,
          bottom: -50,
          child: Opacity(opacity: 0.07, child: Image.asset('assets/brand/symbol_inverse.png', width: 230, color: Colors.white)),
        ),
        SafeArea(
          bottom: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 10, 8, 26),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Image.asset('assets/brand/logo_inverse.png', height: 30),
                const Spacer(),
                IconButton(onPressed: _about, icon: const Icon(Icons.info_outline, color: Colors.white), tooltip: 'À propos'),
              ]),
              const SizedBox(height: 22),
              const Text('SCAN', style: TextStyle(color: CC.orangeLight, fontWeight: FontWeight.w800, letterSpacing: 3, fontSize: 12)),
              const SizedBox(height: 6),
              const Text('Images et PDF\nen Word et Excel.',
                  style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w800, height: 1.15)),
              const SizedBox(height: 14),
              Wrap(spacing: 8, runSpacing: 8, children: const [
                _Chip(Icons.person_off_outlined, 'Sans compte'),
                _Chip(Icons.phonelink_lock_outlined, '100 % sur le téléphone'),
                _Chip(Icons.money_off, 'Gratuit'),
              ]),
            ]),
          ),
        ),
      ]),
    );
  }
}

class _Chip extends StatelessWidget {
  const _Chip(this.icon, this.label);
  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(30)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 15, color: CC.orangeLight),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
        ]),
      );
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({required this.icon, required this.color, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) => CardBox(
        onTap: onTap,
        child: Row(children: [
          IconTile(icon, color: color, size: 54),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: context.strong)),
              const SizedBox(height: 3),
              Text(subtitle, style: TextStyle(fontSize: 12.5, color: context.muted, height: 1.35)),
            ]),
          ),
          Icon(Icons.chevron_right, color: context.muted),
        ]),
      );
}
