import 'package:flutter/material.dart';

/// Charte CHIFFRE CONSEIL (Brand Book « Le C décisif »).
class CC {
  CC._();
  static const navy = Color(0xFF0E1B4D);
  static const navySoft = Color(0xFF16265F);
  static const navyDeep = Color(0xFF0A1439);
  static const orange = Color(0xFFFF5A1F);
  static const orangeText = Color(0xFFC2410C);
  static const orangeLight = Color(0xFFFF8A5C);
  static const blue = Color(0xFF2F6BFF);
  static const mist = Color(0xFFF5F7FA);
  static const line = Color(0xFFDDE2EC);
  static const ink = Color(0xFF1F2A44);
  static const steel = Color(0xFF5B6478);
  static const word = Color(0xFF2B579A);
  static const excel = Color(0xFF1E7145);
  static const success = Color(0xFF12A150);
  static const danger = Color(0xFFD92D20);
  static const darkBg = Color(0xFF070D24);
  static const darkSurface = Color(0xFF0F1838);
  static const darkCard = Color(0xFF152048);
  static const darkLine = Color(0xFF26325E);
  static const darkText = Color(0xFFE8ECF7);
  static const darkMuted = Color(0xFFA3ACC7);
}

ThemeData buildTheme(Brightness b) {
  final dark = b == Brightness.dark;
  final scheme = ColorScheme.fromSeed(
    seedColor: CC.navy,
    brightness: b,
    primary: dark ? CC.orangeLight : CC.navy,
    secondary: CC.orange,
    surface: dark ? CC.darkSurface : Colors.white,
    onSurface: dark ? CC.darkText : CC.ink,
  );
  final base = dark ? Typography.material2021().white : Typography.material2021().black;
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    fontFamily: 'Montserrat',
    scaffoldBackgroundColor: dark ? CC.darkBg : CC.mist,
    textTheme: base.apply(fontFamily: 'Montserrat', bodyColor: scheme.onSurface, displayColor: scheme.onSurface),
  );
}

extension Ctx on BuildContext {
  bool get isDark => Theme.of(this).brightness == Brightness.dark;
  Color get card => isDark ? CC.darkCard : Colors.white;
  Color get lineC => isDark ? CC.darkLine : CC.line;
  Color get strong => isDark ? CC.darkText : CC.navy;
  Color get muted => isDark ? CC.darkMuted : CC.steel;
  Color get accent => isDark ? CC.orangeLight : CC.orangeText;
}
