import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';

class ExportItem {
  final String name;
  final String path;
  final String kind; // docx | xlsx | txt
  final DateTime date;
  final int pages;
  const ExportItem({required this.name, required this.path, required this.kind, required this.date, required this.pages});

  Map<String, dynamic> toJson() => {'n': name, 'p': path, 'k': kind, 'd': date.toIso8601String(), 'g': pages};

  factory ExportItem.fromJson(Map<String, dynamic> j) => ExportItem(
        name: (j['n'] ?? '').toString(),
        path: (j['p'] ?? '').toString(),
        kind: (j['k'] ?? '').toString(),
        date: DateTime.tryParse((j['d'] ?? '').toString()) ?? DateTime.now(),
        pages: (j['g'] is int) ? j['g'] as int : 1,
      );
}

/// Fichiers créés : enregistrés dans le dossier privé de l'application
/// (aucun compte, aucun envoi), puis ouverts ou copiés où l'utilisateur le souhaite.
class ExportStore {
  ExportStore._();
  static final instance = ExportStore._();

  /// Incrémenté à chaque création ou suppression (rafraîchit l'accueil).
  final changes = ValueNotifier<int>(0);

  Future<Directory> _dir() async {
    final base = await getApplicationDocumentsDirectory();
    final d = Directory('${base.path}/exports');
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  Future<File> _historyFile() async => File('${(await _dir()).path}/historique.json');

  Future<List<ExportItem>> history() async {
    try {
      final f = await _historyFile();
      if (!await f.exists()) return [];
      final list = jsonDecode(await f.readAsString()) as List;
      final items = list.whereType<Map>().map((m) => ExportItem.fromJson(Map<String, dynamic>.from(m))).toList();
      final existing = <ExportItem>[];
      for (final i in items) {
        if (await File(i.path).exists()) existing.add(i);
      }
      return existing;
    } catch (_) {
      return [];
    }
  }

  Future<void> _saveHistory(List<ExportItem> items) async {
    final f = await _historyFile();
    await f.writeAsString(jsonEncode(items.map((e) => e.toJson()).toList()));
  }

  static String safeName(String base) {
    final s = base.replaceAll(RegExp(r'[^A-Za-z0-9À-ÿ _-]'), '').trim().replaceAll(RegExp(r'\s+'), '_');
    return s.isEmpty ? 'Scan' : (s.length > 60 ? s.substring(0, 60) : s);
  }

  Future<ExportItem> save(Uint8List bytes, {required String baseName, required String ext, required int pages}) async {
    final d = await _dir();
    var name = '${safeName(baseName)}.$ext';
    var i = 2;
    while (await File('${d.path}/$name').exists()) {
      name = '${safeName(baseName)}_$i.$ext';
      i++;
    }
    final f = File('${d.path}/$name');
    await f.writeAsBytes(bytes, flush: true);
    final item = ExportItem(name: name, path: f.path, kind: ext, date: DateTime.now(), pages: pages);
    final h = await history();
    await _saveHistory([item, ...h]);
    changes.value++;
    return item;
  }

  Future<void> delete(ExportItem item) async {
    try {
      final f = File(item.path);
      if (await f.exists()) await f.delete();
    } catch (_) {}
    final h = await history();
    await _saveHistory(h.where((e) => e.path != item.path).toList());
    changes.value++;
  }

  /// Ouvre le fichier dans Word, Excel, WPS, Google Docs/Sheets… Retourne un message d'erreur ou null.
  Future<String?> open(ExportItem item) async {
    final mime = switch (item.kind) {
      'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      _ => 'text/plain',
    };
    try {
      final r = await OpenFilex.open(item.path, type: mime);
      if (r.type == ResultType.done) return null;
      if (r.type == ResultType.noAppToOpen) {
        return 'Aucune application ne peut ouvrir ce fichier. Installez Microsoft Word / Excel, WPS Office ou Google Docs / Sheets.';
      }
      return r.message;
    } catch (e) {
      return 'Ouverture impossible : $e';
    }
  }

  /// Copie le fichier à l'emplacement choisi (Téléchargements, Drive…). Retourne true si enregistré.
  Future<bool> saveAs(ExportItem item) async {
    final bytes = await File(item.path).readAsBytes();
    final path = await FilePicker.platform.saveFile(
      dialogTitle: 'Enregistrer le fichier',
      fileName: item.name,
      bytes: bytes,
    );
    return path != null;
  }
}
