import 'dart:convert';
import 'dart:typed_data';

/// Écrit une archive ZIP (méthode « stored », sans compression) : c'est le
/// conteneur des fichiers .docx et .xlsx. Aucune dépendance externe.
class ZipWriter {
  final _entries = <_Entry>[];

  void addText(String name, String content) => addBytes(name, Uint8List.fromList(utf8.encode(content)));

  void addBytes(String name, Uint8List data) => _entries.add(_Entry(name, data));

  Uint8List build() {
    final out = BytesBuilder();
    final central = BytesBuilder();
    // date DOS fixe (01/01/2024 00:00) pour un résultat reproductible
    const dosTime = 0;
    const dosDate = ((2024 - 1980) << 9) | (1 << 5) | 1;
    for (final e in _entries) {
      final name = utf8.encode(e.name);
      final crc = crc32(e.data);
      final offset = out.length;
      final h = _Buf()
        ..u32(0x04034b50)
        ..u16(20)
        ..u16(0x0800) // noms en UTF-8
        ..u16(0) // stored
        ..u16(dosTime)
        ..u16(dosDate)
        ..u32(crc)
        ..u32(e.data.length)
        ..u32(e.data.length)
        ..u16(name.length)
        ..u16(0);
      out.add(h.bytes);
      out.add(name);
      out.add(e.data);

      final c = _Buf()
        ..u32(0x02014b50)
        ..u16(20)
        ..u16(20)
        ..u16(0x0800)
        ..u16(0)
        ..u16(dosTime)
        ..u16(dosDate)
        ..u32(crc)
        ..u32(e.data.length)
        ..u32(e.data.length)
        ..u16(name.length)
        ..u16(0)
        ..u16(0)
        ..u16(0)
        ..u16(0)
        ..u32(0)
        ..u32(offset);
      central.add(c.bytes);
      central.add(name);
    }
    final cdOffset = out.length;
    final cd = central.toBytes();
    out.add(cd);
    final end = _Buf()
      ..u32(0x06054b50)
      ..u16(0)
      ..u16(0)
      ..u16(_entries.length)
      ..u16(_entries.length)
      ..u32(cd.length)
      ..u32(cdOffset)
      ..u16(0);
    out.add(end.bytes);
    return out.toBytes();
  }
}

class _Entry {
  final String name;
  final Uint8List data;
  _Entry(this.name, this.data);
}

class _Buf {
  final _b = BytesBuilder();
  void u16(int v) => _b.add([v & 0xff, (v >> 8) & 0xff]);
  void u32(int v) => _b.add([v & 0xff, (v >> 8) & 0xff, (v >> 16) & 0xff, (v >> 24) & 0xff]);
  Uint8List get bytes => _b.toBytes();
}

final List<int> _crcTable = List<int>.generate(256, (n) {
  var c = n;
  for (var k = 0; k < 8; k++) {
    c = (c & 1) != 0 ? 0xEDB88320 ^ (c >> 1) : c >> 1;
  }
  return c;
});

int crc32(List<int> data) {
  var c = 0xFFFFFFFF;
  for (final b in data) {
    c = _crcTable[(c ^ b) & 0xff] ^ (c >> 8);
  }
  return (c ^ 0xFFFFFFFF) & 0xFFFFFFFF;
}

/// Échappement XML + suppression des caractères interdits en XML 1.0.
String xmlEscape(String s) {
  final clean = s.replaceAll(RegExp(r'[\u0000-\u0008\u000B\u000C\u000E-\u001F￾￿]'), '');
  return clean
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;');
}
