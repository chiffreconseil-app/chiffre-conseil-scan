import 'dart:typed_data';

import 'zip_writer.dart';

/// Contenu d'une page à écrire dans Word.
class DocPage {
  final List<String> paragraphs;
  final List<List<String>>? table; // si non nul : la page est écrite en tableau
  const DocPage({this.paragraphs = const [], this.table});
}

const _w = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';

String _run(String text, {bool bold = false, int size = 22, String color = ''}) {
  final rpr = StringBuffer('<w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:cs="Calibri"/>');
  if (bold) rpr.write('<w:b/>');
  if (color.isNotEmpty) rpr.write('<w:color w:val="$color"/>');
  rpr.write('<w:sz w:val="$size"/></w:rPr>');
  // les retours à la ligne internes deviennent des <w:br/>
  final parts = text.split('\n');
  final b = StringBuffer();
  for (var i = 0; i < parts.length; i++) {
    if (i > 0) b.write('<w:br/>');
    b.write('<w:t xml:space="preserve">${xmlEscape(parts[i])}</w:t>');
  }
  return '<w:r>$rpr$b</w:r>';
}

String _para(String text, {bool bold = false, int size = 22, String color = '', int after = 120}) =>
    '<w:p><w:pPr><w:spacing w:after="$after" w:line="276" w:lineRule="auto"/></w:pPr>${text.isEmpty ? '' : _run(text, bold: bold, size: size, color: color)}</w:p>';

String _table(List<List<String>> rows) {
  if (rows.isEmpty) return '';
  final cols = rows.map((r) => r.length).fold<int>(0, (m, l) => l > m ? l : m);
  if (cols == 0) return '';
  const total = 9638; // largeur utile A4 (marges 2 cm), en twips
  final w = total ~/ cols;
  const border = 'w:val="single" w:sz="4" w:space="0" w:color="A6A6A6"';
  final b = StringBuffer('<w:tbl><w:tblPr><w:tblW w:w="$total" w:type="dxa"/><w:tblBorders>'
      '<w:top $border/><w:left $border/><w:bottom $border/><w:right $border/>'
      '<w:insideH $border/><w:insideV $border/></w:tblBorders>'
      '<w:tblLayout w:type="fixed"/><w:tblCellMar><w:left w:w="80" w:type="dxa"/><w:right w:w="80" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>');
  for (var i = 0; i < cols; i++) {
    b.write('<w:gridCol w:w="$w"/>');
  }
  b.write('</w:tblGrid>');
  for (final r in rows) {
    b.write('<w:tr>');
    for (var i = 0; i < cols; i++) {
      final t = i < r.length ? r[i] : '';
      b.write('<w:tc><w:tcPr><w:tcW w:w="$w" w:type="dxa"/></w:tcPr>'
          '<w:p><w:pPr><w:spacing w:after="0"/></w:pPr>${t.isEmpty ? '' : _run(t, size: 20)}</w:p></w:tc>');
    }
    b.write('</w:tr>');
  }
  b.write('</w:tbl>');
  return b.toString();
}

/// Génère un fichier .docx (Word, LibreOffice, Google Docs, WPS).
Uint8List buildDocx(List<DocPage> pages, {String title = ''}) {
  final body = StringBuffer();
  if (title.isNotEmpty) body.write(_para(title, bold: true, size: 32, color: '0E1B4D', after: 240));
  for (var p = 0; p < pages.length; p++) {
    if (p > 0) body.write('<w:p><w:r><w:br w:type="page"/></w:r></w:p>');
    final pg = pages[p];
    if (pg.table != null && pg.table!.isNotEmpty) {
      body.write(_table(pg.table!));
      body.write(_para(''));
    } else {
      for (final para in pg.paragraphs) {
        body.write(_para(para));
      }
    }
  }
  final document = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
      '<w:document xmlns:w="$_w"><w:body>$body'
      '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/>'
      '<w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/>'
      '</w:sectPr></w:body></w:document>';

  final z = ZipWriter()
    ..addText('[Content_Types].xml',
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
        '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
        '</Types>')
    ..addText('_rels/.rels',
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
        '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
        '</Relationships>')
    ..addText('docProps/core.xml',
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>${xmlEscape(title)}</dc:title>'
        '<dc:creator>Chiffre Conseil Scan</dc:creator></cp:coreProperties>')
    ..addText('word/document.xml', document);
  return z.build();
}
