import 'dart:typed_data';

import '../ocr/layout.dart';
import 'zip_writer.dart';

class SheetData {
  final String name;
  final List<List<String>> rows;
  const SheetData(this.name, this.rows);
}

/// "A", "B", … "Z", "AA"…
String columnLetter(int index) {
  var n = index + 1;
  var s = '';
  while (n > 0) {
    final m = (n - 1) % 26;
    s = String.fromCharCode(65 + m) + s;
    n = (n - 1) ~/ 26;
  }
  return s;
}

String _sheetName(String raw, Set<String> used) {
  var n = raw.replaceAll(RegExp(r'[\[\]\*\?/\\:]'), ' ').trim();
  if (n.isEmpty) n = 'Feuille';
  if (n.length > 31) n = n.substring(0, 31);
  var candidate = n;
  var i = 2;
  while (used.contains(candidate.toLowerCase())) {
    final suffix = ' ($i)';
    candidate = (n.length + suffix.length > 31 ? n.substring(0, 31 - suffix.length) : n) + suffix;
    i++;
  }
  used.add(candidate.toLowerCase());
  return candidate;
}

String _sheetXml(List<List<String>> rows, {bool convertNumbers = true}) {
  final cols = rows.map((r) => r.length).fold<int>(0, (m, l) => l > m ? l : m);
  final b = StringBuffer('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
      '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">');
  if (cols > 0) {
    b.write('<cols>');
    for (var c = 0; c < cols; c++) {
      var maxLen = 6;
      for (final r in rows) {
        if (c < r.length && r[c].length > maxLen) maxLen = r[c].length;
      }
      final width = maxLen > 60 ? 60 : maxLen + 2;
      b.write('<col min="${c + 1}" max="${c + 1}" width="$width" customWidth="1"/>');
    }
    b.write('</cols>');
  }
  b.write('<sheetData>');
  for (var r = 0; r < rows.length; r++) {
    b.write('<row r="${r + 1}">');
    for (var c = 0; c < rows[r].length; c++) {
      final v = rows[r][c];
      if (v.trim().isEmpty) continue;
      final ref = '${columnLetter(c)}${r + 1}';
      final number = convertNumbers ? parseNumber(v) : null;
      final style = r == 0 ? ' s="1"' : '';
      if (number != null && number.isFinite) {
        b.write('<c r="$ref"$style><v>${_numText(number)}</v></c>');
      } else {
        b.write('<c r="$ref" t="inlineStr"$style><is><t xml:space="preserve">${xmlEscape(v)}</t></is></c>');
      }
    }
    b.write('</row>');
  }
  b.write('</sheetData></worksheet>');
  return b.toString();
}

String _numText(double v) {
  if (v == v.roundToDouble() && v.abs() < 1e15) return v.toInt().toString();
  return v.toString();
}

const _styles = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
    '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts>'
    '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>'
    '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
    '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
    '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
    '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs>'
    '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
    '</styleSheet>';

/// Génère un classeur .xlsx (Excel, LibreOffice, Google Sheets, WPS).
/// [boldHeader] : met en gras la première ligne de chaque feuille.
Uint8List buildXlsx(List<SheetData> sheets, {bool convertNumbers = true}) {
  final list = sheets.isEmpty ? [const SheetData('Feuille 1', [])] : sheets;
  final used = <String>{};
  final names = [for (final s in list) _sheetName(s.name, used)];

  final ct = StringBuffer('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
      '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
      '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
      '<Default Extension="xml" ContentType="application/xml"/>'
      '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
      '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>');
  final wb = StringBuffer('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
      '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
      'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>');
  final rels = StringBuffer('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
      '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">');
  for (var i = 0; i < list.length; i++) {
    ct.write('<Override PartName="/xl/worksheets/sheet${i + 1}.xml" '
        'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>');
    wb.write('<sheet name="${xmlEscape(names[i])}" sheetId="${i + 1}" r:id="rId${i + 1}"/>');
    rels.write('<Relationship Id="rId${i + 1}" '
        'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" '
        'Target="worksheets/sheet${i + 1}.xml"/>');
  }
  ct.write('</Types>');
  wb.write('</sheets></workbook>');
  rels.write('<Relationship Id="rId${list.length + 1}" '
      'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
      '</Relationships>');

  final z = ZipWriter()
    ..addText('[Content_Types].xml', ct.toString())
    ..addText('_rels/.rels',
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        '</Relationships>')
    ..addText('xl/workbook.xml', wb.toString())
    ..addText('xl/_rels/workbook.xml.rels', rels.toString())
    ..addText('xl/styles.xml', _styles);
  for (var i = 0; i < list.length; i++) {
    z.addText('xl/worksheets/sheet${i + 1}.xml', _sheetXml(list[i].rows, convertNumbers: convertNumbers));
  }
  return z.build();
}
